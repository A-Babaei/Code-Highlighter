document.addEventListener('DOMContentLoaded', () => {
  console.log("ACH Custom Script: DOMContentLoaded event fired.");

  // Check if Prism object is available
  if (typeof Prism === 'undefined') {
    console.error("ACH Custom Script: Prism is not defined. Make sure prism.js is loaded correctly.");
    return;
  }

  console.log("ACH Custom Script: Prism object is available.");

  // A short delay to ensure all Prism plugins have loaded, especially in a dynamic environment.
  setTimeout(() => {
    console.log("ACH Custom Script: Calling Prism.highlightAll().");
    try {
      Prism.highlightAll();
      console.log("ACH Custom Script: Prism.highlightAll() executed successfully.");
    } catch (e) {
      console.error("ACH Custom Script: Error calling Prism.highlightAll().", e);
    }
  }, 100); // 100ms delay
});
