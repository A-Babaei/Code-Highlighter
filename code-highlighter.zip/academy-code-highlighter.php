<?php
/**
 * Plugin Name:       Academy Code Highlighter
 * Plugin URI:        https://academy-tech.ir/
 * Description:       A modern plugin to automatically highlight code blocks with a dark theme and a copy button.
 * Version:           1.2.0
 * Author:            Jules for Academy-Tech.ir
 * Author URI:        https://academy-tech.ir/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       academy-code-highlighter
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// A flag to check if assets should be loaded.
$ach_assets_needed = false;

/**
 * Check if the post content contains a code block.
 * If so, set a flag to enqueue assets later.
 *
 * @param array $posts The array of posts being displayed.
 * @return array The unmodified array of posts.
 */
function ach_check_for_code_blocks( $posts ) {
    global $ach_assets_needed;

    if ( $ach_assets_needed ) {
        return $posts;
    }

    foreach ( $posts as $post ) {
        if ( has_shortcode( $post->post_content, 'code' ) || false !== strpos( $post->post_content, '<pre' ) ) {
            $ach_assets_needed = true;
            break;
        }
    }

    return $posts;
}
add_filter( 'the_posts', 'ach_check_for_code_blocks', 10, 1 );

/**
 * Enqueue Prism.js assets for syntax highlighting.
 *
 * Only loads assets if a code block was detected on the page.
 */
function ach_enqueue_prism_assets() {
    global $ach_assets_needed;

    if ( is_singular() && $ach_assets_needed ) {
        // Enqueue Prism.js CSS from CDN
        wp_enqueue_style(
            'ach-prism-tomorrow-css',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css',
            [],
            '1.29.0'
        );
        wp_enqueue_style(
            'ach-prism-line-numbers-css',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/line-numbers/prism-line-numbers.min.css',
            ['ach-prism-tomorrow-css'],
            '1.29.0'
        );
        wp_enqueue_style(
            'ach-prism-toolbar-css',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/toolbar/prism-toolbar.min.css',
            ['ach-prism-tomorrow-css'],
            '1.29.0'
        );

        // Enqueue Custom Dark Theme
        $plugin_url = plugin_dir_url( __FILE__ );
        wp_enqueue_style(
            'ach-custom-dark-theme-css',
            $plugin_url . 'assets/css/custom-dark-theme.css',
            ['ach-prism-tomorrow-css'],
            '1.2.0'
        );

        // Enqueue Prism.js Core from CDN
        wp_enqueue_script(
            'ach-prism-core-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js',
            [],
            '1.29.0',
            true // Load in the footer
        );

        // Enqueue Prism.js components from CDN
        wp_enqueue_script(
            'ach-prism-components-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-c.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );
        wp_enqueue_script(
            'ach-prism-python-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );
        wp_enqueue_script(
            'ach-prism-php-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-php.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );
        wp_enqueue_script(
            'ach-prism-matlab-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-matlab.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );
        wp_enqueue_script(
            'ach-prism-markup-templating-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-markup-templating.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );

        // Enqueue Prism.js plugins from CDN
        wp_enqueue_script(
            'ach-prism-line-numbers-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/line-numbers/prism-line-numbers.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );
        wp_enqueue_script(
            'ach-prism-toolbar-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/toolbar/prism-toolbar.min.js',
            ['ach-prism-core-js'],
            '1.29.0',
            true
        );
        wp_enqueue_script(
            'ach-prism-copy-to-clipboard-js',
            'https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/copy-to-clipboard/prism-copy-to-clipboard.min.js',
            ['ach-prism-toolbar-js'],
            '1.29.0',
            true
        );
        
        // Enqueue the custom script for debugging and initialization
        $plugin_url = plugin_dir_url( __FILE__ );
        wp_enqueue_script(
            'ach-custom-script-js',
            $plugin_url . 'assets/js/custom-script.js',
            ['ach-prism-copy-to-clipboard-js'], // Dependency on the last loaded prism script
            '1.2.0',
            true // Load in the footer
        );
    }
}
add_action( 'wp_enqueue_scripts', 'ach_enqueue_prism_assets' );

/**
 * Register the [code] shortcode for highlighting code.
 *
 * Usage: [code language="python"]...your code...[/code]
 * If 'language' is omitted, it defaults to 'python'.
 *
 * @param array  $atts    Shortcode attributes.
 * @param string $content The content enclosed by the shortcode.
 * @return string The formatted HTML for the code block.
 */
function ach_code_shortcode( $atts, $content = null ) {
    // Sanitize the content by escaping HTML entities.
    $content = esc_html( $content );

    // Set default attributes and merge with user-provided attributes.
    $atts = shortcode_atts(
        [
            'language' => 'python', // Default to Python
        ],
        $atts,
        'code'
    );

    $language = esc_attr( $atts['language'] );

    // Return the formatted code block. The classes on the <pre> tag are essential for styling and plugins.
    $output = "<pre class=\"line-numbers toolbar language-{$language}\"><code class=\"language-{$language}\">{$content}</code></pre>";

    return $output;
}
add_shortcode( 'code', 'ach_code_shortcode' );

/**
 * Merge adjacent <pre> blocks into a single block.
 *
 * This function is a workaround for the WordPress block editor, which often
 * saves each line of a code block as a separate <pre> element. This function
 * parses the post content, finds adjacent <pre> blocks, and merges them to
 * ensure they are treated as a single block for syntax highlighting.
 *
 * @param string $content The post content.
 * @return string The modified post content with adjacent code blocks merged.
 */
function ach_merge_adjacent_code_blocks( $content ) {
    // If there are no <pre> tags, no need to do anything.
    if ( false === strpos( $content, '<pre' ) ) {
        return $content;
    }

    // Use DOMDocument to safely parse and manipulate the HTML.
    $doc = new DOMDocument();
    // Suppress warnings from potentially malformed HTML.
    libxml_use_internal_errors( true );
    // Load the content, adding a wrapper and specifying UTF-8 to handle encoding correctly.
    $doc->loadHTML( '<div id="post-content-wrapper">' . mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ) . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
    libxml_clear_errors();

    $xpath = new DOMXPath( $doc );
    $pres = $xpath->query( '//pre' );

    if ( $pres->length < 2 ) {
        return $content;
    }

    $merged = false;
    $i = 0;
    while ( $i < $pres->length ) {
        $current_pre = $pres->item( $i );
        $next_element = $current_pre->nextSibling;

        // Find the next actual element sibling, skipping whitespace nodes.
        while ( $next_element && $next_element->nodeType === XML_TEXT_NODE && trim( $next_element->nodeValue ) === '' ) {
            $next_element = $next_element->nextSibling;
        }

        if ( $next_element && $next_element->nodeName === 'pre' ) {
            $current_code = $current_pre->getElementsByTagName( 'code' )->item( 0 );
            $next_code = $next_element->getElementsByTagName( 'code' )->item( 0 );

            if ( $current_code && $next_code ) {
                // Append the content of the next code block to the current one.
                $current_code->nodeValue .= "\n" . $next_code->nodeValue;
                // Remove the merged block.
                $next_element->parentNode->removeChild( $next_element );
                $merged = true;
                // Re-run the query to get a live list of <pre> elements
                $pres = $xpath->query('//pre');
                // Do not increment $i, so we can check if the *new* next sibling is also a <pre>
                continue;
            }
        }
        $i++;
    }


    if ( $merged ) {
        $wrapper = $doc->getElementById('post-content-wrapper');
        if ($wrapper) {
            $content = '';
            foreach ($wrapper->childNodes as $childNode) {
                $content .= $doc->saveHTML($childNode);
            }
        }
    }

    return $content;
}
add_filter( 'the_content', 'ach_merge_adjacent_code_blocks', 5 );


/**
 * Automatically add Prism.js classes to <pre> and <code> blocks that are not
 * already highlighted.
 *
 * This function is designed to target default Gutenberg code blocks, which are
 * wrapped in `<pre>` tags but do not have syntax highlighting classes. It
 * intelligently adds the required classes without creating duplicate `class` attributes.
 *
 * @param string $content The post content.
 * @return string The modified post content.
 */
function ach_add_default_language_class( $content ) {
    // This regex finds any <pre> tag immediately followed by a <code> tag.
    $pattern = '/<pre(.*?)><code(.*?)>(.*?)<\/code><\/pre>/is';

    return preg_replace_callback(
        $pattern,
        function( $matches ) {
            $pre_attributes = $matches[1];
            $code_attributes = $matches[2];
            $code_content = $matches[3];

            // If the <code> tag already has a "language-" class, do nothing.
            if ( preg_match( '/class=.*[\'"]language-/', $code_attributes ) ) {
                return $matches[0]; // Return the original, unmodified block.
            }

            // --- Define classes to add ---
            $pre_classes_to_add = 'line-numbers toolbar language-python';
            $code_classes_to_add = 'language-python';

            // --- Safely add classes to the <pre> tag ---
            if ( preg_match( '/class=(["\'])(.*?)\1/', $pre_attributes, $class_matches ) ) {
                // Class attribute exists, so append new classes.
                $existing_classes = $class_matches[2];
                $new_classes = trim( $existing_classes . ' ' . $pre_classes_to_add );
                $pre_attributes = str_replace( $class_matches[0], 'class="' . $new_classes . '"', $pre_attributes );
            } else {
                // No class attribute, so add a new one.
                $pre_attributes .= ' class="' . $pre_classes_to_add . '"';
            }

            // --- Safely add classes to the <code> tag ---
            if ( preg_match( '/class=(["\'])(.*?)\1/', $code_attributes, $class_matches ) ) {
                // Class attribute exists, so append new classes.
                $existing_classes = $class_matches[2];
                $new_classes = trim( $existing_classes . ' ' . $code_classes_to_add );
                $code_attributes = str_replace( $class_matches[0], 'class="' . $new_classes . '"', $code_attributes );
            } else {
                // No class attribute, so add a new one.
                $code_attributes .= ' class="' . $code_classes_to_add . '"';
            }

            // Reconstruct and return the modified HTML.
            return "<pre{$pre_attributes}><code{$code_attributes}>{$code_content}</code></pre>";
        },
        $content
    );
}
add_filter( 'the_content', 'ach_add_default_language_class' );
