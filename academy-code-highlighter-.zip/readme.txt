=== Academy Code Highlighter ===
Contributors: jules
Tags: code, syntax, highlighter, prism, developer, education
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.1.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A modern, lightweight plugin to automatically highlight code blocks in a beautiful dark theme, complete with a copy-to-clipboard button.

== Description ==

The **Academy Code Highlighter** plugin makes it easy to display beautiful, modern, and functional code blocks on your WordPress site. It's designed for educational blogs and tutorial websites, especially those focusing on languages like Python, MATLAB, PHP, and JavaScript.

The plugin automatically detects `<pre><code>` blocks and applies a professional "Tomorrow Night" theme with line numbers and a convenient "Copy" button. If no language is specified, it **defaults to Python**.

It's built to be fast and efficient, loading assets only when needed.

**Features:**
*   **Modern Dark Theme:** A beautiful, readable "Tomorrow Night" dark theme for all your code blocks.
*   **Copy to Clipboard Button:** A subtle "Copy" button appears on hover in the top-right corner of every code block.
*   **Automatic Highlighting:** No setup needed. The plugin finds and highlights code blocks, defaulting to Python.
*   **CDN-Powered:** Uses the reliable jsDelivr CDN to load Prism.js, ensuring your site is fast and always using the latest version.
*   **Multiple Languages:** Supports Python, MATLAB, PHP, JavaScript, CSS, and HTML out of the box.
*   **Line Numbers:** Enabled by default for a professional look.
*   **Easy Shortcode:** Use `[code language="python"]...[/code]` for quick embedding, especially in the Classic Editor.

== Installation ==

1.  Upload the `academy-code-highlighter` folder to the `/wp-content/plugins/` directory.
2.  Activate the plugin through the 'Plugins' menu in WordPress.
3.  That's it! Start adding code to your posts and pages.

== Usage ==

The plugin is designed to work automatically with WordPress's built-in code formatting tools.

**Gutenberg (Block Editor):**

1.  Create a new post or page.
2.  Add a "Code" block.
3.  Write or paste your code into the block.
4.  In the block's sidebar settings, under "Advanced," add the appropriate language class to the "Additional CSS Class(es)" field. For example: `language-python` or `language-matlab`.
5.  Publish the page. The code will be highlighted automatically.

**Classic Editor:**

1.  Switch to the "Text" tab in the editor.
2.  Wrap your code in `<pre>` and `<code>` tags.
3.  Add the language class to the `<code>` tag. Example:
    `<pre><code class="language-python">
    def hello():
        print("Hello, World!")
    </code></pre>`
4.  Publish the page.

**Using the Shortcode:**

You can also use the `[code]` shortcode in any editor. This is especially useful in the Classic Editor.

`[code language="python"]
def greet(name):
  return f"Hello, {name}!"

print(greet('Jules'))
[/code]`

If you omit the `language` attribute, it will default to `python`.

`[code]
# This will be highlighted as Python code by default.
print("Defaulting to Python!")
[/code]`

== Changelog ==

See `changelog.md` for the full changelog.
