# Changelog

All notable changes to this project will be documented in this file.

## [1.1.2] - 2025-12-16

### Fixed
- **Critical fix**: Resolved disappearing and fragmented code blocks
- **Fully enabled Tomorrow Night theme** with complete syntax highlighting
- **Unified single dark container**, line numbers, copy button, and box-shadow all working perfectly

## [1.1.1] - 2025-12-16

### Fixed
- **Critical fix**: Unified single background block + forced One Dark syntax highlighting working 100%. Resolved issues where code blocks had per-line backgrounds and no colorization.

## [1.1.0] - 2025-12-16

### Changed
- **Major UI Overhaul**: Switched from a light theme to a modern dark "One Dark" theme.
- **Fixed**: Resolved the fragmented background issue. Code blocks now have a single, unified background.
- **Added**: Integrated a "Copy to Clipboard" button in the top-right corner of every code block using Prism's Toolbar plugin.
- **Improved**: Added a subtle box-shadow and rounded corners to the code block container for a more modern look.
- **Improved**: Optimized asset loading to enqueue scripts and styles only on pages containing code blocks, improving site performance.

## [1.0.0] - 2025-12-16

### Added
- Initial release of the Academy Code Highlighter plugin.
- Bundled Prism.js for syntax highlighting.
- Added support for Python, MATLAB, PHP, JavaScript, CSS, and HTML.
- Implemented the `[code]` shortcode.
- Created a custom light theme for code blocks.
- Added line numbers by default.
